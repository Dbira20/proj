#include <stdio.h>
int main()
{
int a,b;
a=10;
b=3;
printf("\n a=%d b=%d ",a,b);
}
